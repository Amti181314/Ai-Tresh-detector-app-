from flask import Flask, render_template, Response, jsonify
import cv2
import numpy as np
from ultralytics import YOLO
import json
import time

app = Flask(__name__)

# Load pre-trained YOLO model (using YOLOv8 nano for speed)
model = YOLO('yolov8n.pt')  # This will download automatically if not present

# Global variables
camera = None
detection_results = []

def get_camera():
    global camera
    if camera is None:
        camera = cv2.VideoCapture(0)
        camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    return camera

def classify_ash_type(class_name, confidence):
    """
    Classify detected objects as different types of ash/waste
    This is a simple mapping - you can customize based on your needs
    """
    organic_items = ['apple', 'banana', 'orange', 'sandwich', 'pizza', 'cake', 'carrot']
    recyclable_items = ['bottle', 'cup', 'can', 'plastic', 'cardboard', 'paper']
    hazardous_items = ['battery', 'electronics', 'phone', 'laptop']
    
    if class_name.lower() in organic_items:
        return "Organic Ash", "#4CAF50"  # Green
    elif class_name.lower() in recyclable_items:
        return "Recyclable Ash", "#2196F3"  # Blue
    elif class_name.lower() in hazardous_items:
        return "Hazardous Ash", "#F44336"  # Red
    else:
        return "General Ash", "#FF9800"  # Orange

def generate_frames():
    global detection_results
    camera = get_camera()
    
    while True:
        success, frame = camera.read()
        if not success:
            break
        
        # Run YOLO detection
        results = model(frame, verbose=False)
        
        # Process results
        detection_results = []
        annotated_frame = frame.copy()
        
        for result in results:
            boxes = result.boxes
            if boxes is not None:
                for box in boxes:
                    # Get box coordinates
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    confidence = box.conf[0].cpu().numpy()
                    class_id = int(box.cls[0].cpu().numpy())
                    class_name = model.names[class_id]
                    
                    # Only show detections with confidence > 0.5
                    if confidence > 0.5:
                        # Classify ash type
                        ash_type, color = classify_ash_type(class_name, confidence)
                        
                        # Store detection result
                        detection_results.append({
                            'object': class_name,
                            'confidence': float(confidence),
                            'ash_type': ash_type,
                            'bbox': [int(x1), int(y1), int(x2), int(y2)]
                        })
                        
                        # Draw bounding box
                        color_bgr = tuple(int(color.lstrip('#')[i:i+2], 16) for i in (0, 2, 4))[::-1]
                        cv2.rectangle(annotated_frame, (int(x1), int(y1)), (int(x2), int(y2)), color_bgr, 2)
                        
                        # Draw label
                        label = f"{ash_type}: {class_name} ({confidence:.2f})"
                        label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]
                        cv2.rectangle(annotated_frame, (int(x1), int(y1) - label_size[1] - 10), 
                                    (int(x1) + label_size[0], int(y1)), color_bgr, -1)
                        cv2.putText(annotated_frame, label, (int(x1), int(y1) - 5), 
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
        
        # Encode frame
        ret, buffer = cv2.imencode('.jpg', annotated_frame)
        frame = buffer.tobytes()
        
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/detection_data')
def detection_data():
    global detection_results
    return jsonify(detection_results)

@app.route('/start_sorting')
def start_sorting():
    # This endpoint could trigger sorting mechanism
    return jsonify({"status": "Sorting started", "timestamp": time.time()})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)